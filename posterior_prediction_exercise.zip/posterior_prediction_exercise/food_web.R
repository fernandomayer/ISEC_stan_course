
library(rstan)
library("loo")
library("shinystan")
#options(mc.cores = parallel::detectCores())

# read the data
webs <- readr::read_csv("https://raw.githubusercontent.com/PoisotLab/ms_straight_lines/master/data/network_data.dat")

pred <- subset(webs, predation > 0)

## read models

betabin <- rstan::stan_model(file = "betabin_connectance.stan")
conscon <- rstan::stan_model(file = "constant_connect.stan")

# create a list of arguments

predsmall = subset(pred, links < 4e4)

d <- list(
  W = nrow(predsmall),
  L = predsmall$links,
  S = predsmall$nodes
)


# sample models -----------------------------------------------------------

betabin_samples <- rstan::sampling(betabin, data = d, iter = 2000, chains = 4)
conscon_samples <- rstan::sampling(conscon, data = d, iter = 2000, chains = 4)

obs_links <- d$L

##### RUN TO HERE. then try:

# look at diagnostics in shinystan ----------------------------------------

shinystan::launch_shinystan(betabin_samples)
shinystan::launch_shinystan(conscon_samples)


# simple (crude) way to examine posterior predictions ---------------------

betabin_sample_df <- as.data.frame(betabin_samples)

one_sample <- betabin_sample_df %>%
  select(starts_with("y_hat")) %>%
  slice(555) %>%
  unlist


predsmall$fakedata <- one_sample

predsmall %>%
  ggplot(aes(x = nodes, y = links)) +
  geom_point() +
  geom_point(aes(y = fakedata), col = "green") +
  coord_trans(x = "log", y = "log")


# calculate and compare LOO diagnostics -----------------------------------

# adapted from the LOO vignette
# https://mc-stan.org/loo/articles/loo2-with-rstan.html

# Extract pointwise log-likelihood
# using merge_chains=FALSE returns an array, which is easier to
# use with relative_eff()
betabin_log_lik <- extract_log_lik(betabin_samples, merge_chains = FALSE)

# as of loo v2.0.0 we can optionally provide relative effective sample sizes
# when calling loo, which allows for better estimates of the PSIS effective
# sample sizes and Monte Carlo error
betabin_r_eff <- relative_eff(exp(betabin_log_lik))

# preferably use more than 2 cores (as many cores as possible)
# will use value of 'mc.cores' option if cores is not specified
betabin_loo <- loo(betabin_log_lik, r_eff = betabin_r_eff)
print(betabin_loo)

plot(betabin_loo)

## constant connect

conscon_log_lik <- extract_log_lik(conscon_samples, merge_chains = FALSE)
conscon_r_eff <- relative_eff(exp(conscon_log_lik), cores = 4)
conscon_loo <- loo(conscon_log_lik, #r_eff = conscon_r_eff,
                   cores = 4)

# compare -----------------------------------------------------------------

print(betabin_loo)
print(conscon_loo)

loo_compare(betabin_loo, conscon_loo)


loo_compare(list(
  betabin = betabin_loo,
  conscon = conscon_loo))

# plotting loo values -----------------------------------------------------
library(tidyverse)
cbind(predsmall, betabin_loo$pointwise) %>%
  ggplot(aes(x = nodes, y = elpd_loo)) + geom_point()

list(betabin = betabin_loo$pointwise[,1],
     constant = conscon_loo$pointwise[,1]) %>%
  bind_rows %>%
  add_column(S = predsmall$nodes) %>%
  pivot_longer(-S, names_to = "model", values_to = "elpd") %>%
  ggplot(aes(x = S, y = elpd)) + facet_wrap(~model) +
  geom_point()


list(betabin = betabin_loo$diagnostics$pareto_k,
     constant = conscon_loo$diagnostics$pareto_k) %>%
  bind_rows %>%
  add_column(S = predsmall$nodes) %>%
  pivot_longer(-S, names_to = "model", values_to = "elpd") %>%
  ggplot(aes(x = S, y = elpd)) + facet_wrap(~model) +
  geom_point()




